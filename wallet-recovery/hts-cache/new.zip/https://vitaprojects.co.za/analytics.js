<!DOCTYPE html>
<html lang="en-US"  data-menu="leftalign">
<head>

<link rel="profile" href="//gmpg.org/xfn/11" />

 

<title>Page not found &#8211; Vita Projects</title>
<meta name='robots' content='max-image-preview:large' />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /><meta name="format-detection" content="telephone=no"><link rel='dns-prefetch' href='//www.googletagmanager.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Vita Projects &raquo; Feed" href="https://vitaprojects.co.za/feed/" />
<link rel="alternate" type="application/rss+xml" title="Vita Projects &raquo; Comments Feed" href="https://vitaprojects.co.za/comments/feed/" />
		<!-- This site uses the Google Analytics by MonsterInsights plugin v8.3.0 - Using Analytics tracking - https://www.monsterinsights.com/ -->
		<!-- Note: MonsterInsights is not currently configured on this site. The site owner needs to authenticate with Google Analytics in the MonsterInsights settings panel. -->
					<!-- No UA code set -->
				<!-- / Google Analytics by MonsterInsights -->
				<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/vitaprojects.co.za\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://vitaprojects.co.za/wp-includes/css/dist/block-library/style.min.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-vendors-style-css'  href='https://vitaprojects.co.za/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-vendors-style.css?ver=6.3.3' type='text/css' media='all' />
<link rel='stylesheet' id='wc-blocks-style-css'  href='https://vitaprojects.co.za/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/wc-blocks-style.css?ver=6.3.3' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://vitaprojects.co.za/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.5.3' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://vitaprojects.co.za/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.2.18' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='https://vitaprojects.co.za/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=6.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='https://vitaprojects.co.za/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=6.0.0' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='https://vitaprojects.co.za/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=6.0.0' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='dashicons-css'  href='https://vitaprojects.co.za/wp-includes/css/dashicons.min.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='avante-reset-css-css'  href='https://vitaprojects.co.za/wp-content/themes/avante/css/core/reset.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='avante-wordpress-css-css'  href='https://vitaprojects.co.za/wp-content/themes/avante/css/core/wordpress.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='avante-screen-css'  href='https://vitaprojects.co.za/wp-content/themes/avante/css/core/screen.css?ver=5.8.3' type='text/css' media='all' />
<style id='avante-screen-inline-css' type='text/css'>

                	@font-face {
	                	font-family: "GlacialIndifference-Regular";
	                	src: url(http://vitaprojects.co.za/wp-content/themes/avante/fonts/GlacialIndifference-Regular.woff) format("woff");
	                	font-weight: 400;
						font-style: normal;
	                }
                
                	@font-face {
	                	font-family: "GlacialIndifference-Bold";
	                	src: url(http://vitaprojects.co.za/wp-content/themes/avante/fonts/GlacialIndifference-Bold.woff) format("woff");
	                	font-weight: 700;
						font-style: normal;
	                }
                
</style>
<link rel='stylesheet' id='modulobox-css'  href='https://vitaprojects.co.za/wp-content/themes/avante/css/modulobox.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='avante-left-align-menu-css'  href='https://vitaprojects.co.za/wp-content/themes/avante/css/menus/left-align-menu.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='themify-icons-css'  href='https://vitaprojects.co.za/wp-content/themes/avante/css/themify-icons.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='tooltipster-css'  href='https://vitaprojects.co.za/wp-content/themes/avante/css/tooltipster.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='loftloader-lite-animation-css'  href='https://vitaprojects.co.za/wp-content/plugins/loftloader/assets/css/loftloader.min.css?ver=2021102001' type='text/css' media='all' />
<link rel='stylesheet' id='avante-script-responsive-css-css'  href='https://vitaprojects.co.za/wp-content/themes/avante/css/core/responsive.css?ver=5.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='kirki-styles-global-css'  href='https://vitaprojects.co.za/wp-content/themes/avante/modules/kirki/assets/css/kirki-styles.css?ver=3.0.21' type='text/css' media='all' />
<style id='kirki-styles-global-inline-css' type='text/css'>
#right-click-content{background:rgba(0, 0, 0, 0.5);color:#ffffff;}body, input[type=text], input[type=password], input[type=email], input[type=url], input[type=date], input[type=tel], input.wpcf7-text, .woocommerce table.cart td.actions .coupon .input-text, .woocommerce-page table.cart td.actions .coupon .input-text, .woocommerce #content table.cart td.actions .coupon .input-text, .woocommerce-page #content table.cart td.actions .coupon .input-text, select, textarea, .ui-widget input, .ui-widget select, .ui-widget textarea, .ui-widget button, .ui-widget label, .ui-widget-header, .zm_alr_ul_container{font-family:Roboto;font-size:16px;font-weight:400;line-height:1.8;text-transform:none;}h1, h2, h3, h4, h5, h6, h7, .post_quote_title, strong[itemprop="author"], #page-content-wrapper .posts.blog li a, .page-content-wrapper .posts.blog li a, #filter_selected, blockquote, .sidebar-widget li.widget_products, #footer ul.sidebar-widget li ul.posts.blog li a, .woocommerce-page table.cart th, table.shop_table thead tr th, .testimonial_slider_content, .pagination, .pagination-detail{font-family:Cabin;font-weight:700;line-height:1.7;text-transform:none;}h1{font-size:32px;}h2{font-size:28px;}h3{font-size:24px;}h4{font-size:22px;}h5{font-size:20px;}h6{font-size:18px;}body, #wrapper, #page-content-wrapper.fixed, #gallery_lightbox h2, .slider_wrapper .gallery_image_caption h2, #body_loading_screen, h3#reply-title span, .overlay_gallery_wrapper, .pagination a, .pagination span, #captcha-wrap .text-box input, .flex-direction-nav a, .blog_promo_title h6, #supersized li, #horizontal_gallery_wrapper .image_caption, body.password-protected #page-content-wrapper .inner .inner-wrapper .sidebar-content, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"], body .ui-dialog[aria-describedby="ajax-login-register-dialog"], #single-course-meta{background-color:#011826;}body, .pagination a, #gallery_lightbox h2, .slider_wrapper .gallery_image_caption h2, .post_info a, #page-content-wrapper.split #copyright, .page-content-wrapper.split #copyright, .ui-state-default a, .ui-state-default a:link, .ui-state-default a:visited, .woocommerce-MyAccount-navigation ul a, .woocommerce #page-content-wrapper div.product p.price, .woocommerce-page #page-content-wrapper div.product p.price{color:#ffffff;}::selection, .verline{background-color:#ffffff;}::-webkit-input-placeholder{color:#ffffff;}::-moz-placeholder{color:#ffffff;}:-ms-input-placeholder{color:#ffffff;}a, .gallery_proof_filter ul li a, #page-content-wrapper .sidebar .content .sidebar-widget li.widget_rss ul li cite, #footer-wrapper ul.sidebar-widget li.widget_rss ul li cite{color:#181B31;}.flex-control-paging li a.flex-active, .post-attribute a:before, #menu-wrapper .nav ul li a:before, #menu-wrapper div .nav li > a:before, .post-attribute a:before{background-color:#181B31;}.flex-control-paging li a.flex-active, .image_boxed_wrapper:hover, .gallery_proof_filter ul li a.active, .gallery_proof_filter ul li a:hover{border-color:#181B31;}a:hover, a:active, .post_info_comment a i, #commentform .required, #page-content-wrapper .sidebar .content .sidebar-widget li.widget_rss ul li .rss-date, #footer-wrapper ul.sidebar-widget li.widget_rss ul li .rss-date{color:#fbb315;}input[type=button]:hover, input[type=submit]:hover, a.button:hover, .button:hover, .button.submit, a.button.white:hover, .button.white:hover, a.button.white:active, .button.white:active, #menu-wrapper .nav ul li a:hover:before, #menu-wrapper div .nav li > a:hover:before, .post-attribute a:hover:before{background-color:#fbb315;}input[type=button]:hover, input[type=submit]:hover, a.button:hover, .button:hover, .button.submit, a.button.white:hover, .button.white:hover, a.button.white:active, .button.white:active, .sidebar-widget li.widget_recent_comments ul li.recentcomments a:hover{border-color:#fbb315;}h1, h2, h3, h4, h5, h6, h7, pre, code, tt, blockquote, .post-header h5 a, .post-header h3 a, .post-header.grid h6 a, .post-header.fullwidth h4 a, .post-header h5 a, blockquote, .site_loading_logo_item i, .ppb_subtitle, .woocommerce .woocommerce-ordering select, .woocommerce #page-content-wrapper a.button, .woocommerce.columns-4 ul.products li.product a.add_to_cart_button, .woocommerce.columns-4 ul.products li.product a.add_to_cart_button:hover, .ui-accordion .ui-accordion-header a, .tabs .ui-state-active a, .post-header h5 a, .post-header h6 a, .flex-direction-nav a:before, .social_share_button_wrapper .social_post_view .view_number, .social_share_button_wrapper .social_post_share_count .share_number, .portfolio_post_previous a, .portfolio_post_next a, #filter_selected, #autocomplete li strong, .themelink, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"] .ui-dialog-titlebar .ui-dialog-title, body .ui-dialog[aria-describedby="ajax-login-register-dialog"] .ui-dialog-titlebar .ui-dialog-title{color:#181B31;}body.page.page-template-gallery-archive-split-screen-php #fp-nav li .active span, body.tax-gallerycat #fp-nav li .active span, body.page.page-template-portfolio-fullscreen-split-screen-php #fp-nav li .active span, body.page.tax-portfolioset #fp-nav li .active span, body.page.page-template-gallery-archive-split-screen-php #fp-nav ul li a span, body.tax-gallerycat #fp-nav ul li a span, body.page.page-template-portfolio-fullscreen-split-screen-php #fp-nav ul li a span, body.page.tax-portfolioset #fp-nav ul li a span{background-color:#181B31;}hr, .post.type-post, .comment .right, .widget_tag_cloud div a, .meta-tags a, .tag_cloud a, #footer, #post_more_wrapper, #page-content-wrapper .inner .sidebar-content, #page-content-wrapper .inner .sidebar-content.left-sidebar, .ajax_close, .ajax_next, .ajax_prev, .portfolio_next, .portfolio_prev, .portfolio_next_prev_wrapper.video .portfolio_prev, .portfolio_next_prev_wrapper.video .portfolio_next, .separated, .blog_next_prev_wrapper, #post_more_wrapper h5, #ajax_portfolio_wrapper.hidding, #ajax_portfolio_wrapper.visible, .tabs.vertical .ui-tabs-panel, .ui-tabs.vertical.right .ui-tabs-nav li, .woocommerce div.product .woocommerce-tabs ul.tabs li, .woocommerce #content div.product .woocommerce-tabs ul.tabs li, .woocommerce-page div.product .woocommerce-tabs ul.tabs li, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li, .woocommerce div.product .woocommerce-tabs .panel, .woocommerce-page div.product .woocommerce-tabs .panel, .woocommerce #content div.product .woocommerce-tabs .panel, .woocommerce-page #content div.product .woocommerce-tabs .panel, .woocommerce table.shop_table, .woocommerce-page table.shop_table, .woocommerce .cart-collaterals .cart_totals, .woocommerce-page .cart-collaterals .cart_totals, .woocommerce .cart-collaterals .shipping_calculator, .woocommerce-page .cart-collaterals .shipping_calculator, .woocommerce .cart-collaterals .cart_totals tr td, .woocommerce .cart-collaterals .cart_totals tr th, .woocommerce-page .cart-collaterals .cart_totals tr td, .woocommerce-page .cart-collaterals .cart_totals tr th, table tr th, table tr td, .woocommerce #payment, .woocommerce-page #payment, .woocommerce #payment ul.payment_methods li, .woocommerce-page #payment ul.payment_methods li, .woocommerce #payment div.form-row, .woocommerce-page #payment div.form-row, .ui-tabs li:first-child, .ui-tabs .ui-tabs-nav li, .ui-tabs.vertical .ui-tabs-nav li, .ui-tabs.vertical.right .ui-tabs-nav li.ui-state-active, .ui-tabs.vertical .ui-tabs-nav li:last-child, #page-content-wrapper .inner .sidebar-wrapper ul.sidebar-widget li.widget_nav_menu ul.menu li.current-menu-item a, .page-content-wrapper .inner .sidebar-wrapper ul.sidebar-widget li.widget_nav_menu ul.menu li.current-menu-item a, .ui-accordion .ui-accordion-header, .ui-accordion .ui-accordion-content, #page-content-wrapper .sidebar .content .sidebar-widget li h2.widgettitle:before, h2.widgettitle:before, #autocomplete, .ppb_blog_minimal .one-third_bg, .tabs .ui-tabs-panel, .ui-tabs .ui-tabs-nav li, .ui-tabs li:first-child, .ui-tabs.vertical .ui-tabs-nav li:last-child, .woocommerce .woocommerce-ordering select, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active, .woocommerce #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page #content div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page table.cart th, table.shop_table thead tr th, hr.title_break, .overlay_gallery_border, #page-content-wrapper.split #copyright, .page-content-wrapper.split #copyright, .post.type-post, .events.type-events, h5.event_title, .post-header h5.event_title, .client_archive_wrapper, #page-content-wrapper .sidebar .content .sidebar-widget li.widget, .page-content-wrapper .sidebar .content .sidebar-widget li.widget, hr.title_break.bold, blockquote, .social_share_button_wrapper, .social_share_button_wrapper, body:not(.single) .post-wrapper, .theme-border, #about-the-author, .related.products, .woocommerce div.product div.summary .product_meta, #single-course-meta ul.single-course-meta-data li.single-course-meta-data-separator, body .course-curriculum ul.curriculum-sections .section-header, .course-reviews-list li, .course-reviews-list-shortcode li, .wp-block-table, .wp-block-table td, .wp-block-table th, .wp-block-table.is-style-stripes td, .wp-block-table.is-style-stripes th, table, .widget_categories ul > li, .widget_pages ul > li, .widget_archive ul > li, #page-content-wrapper .sidebar .content .sidebar-widget li h2.widgettitle:before, h2.widgettitle:before, #page-content-wrapper .sidebar .content .sidebar-widget li h2.widgettitle:after, h2.widgettitle:after{border-color:#d8d8d8;}input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=date], textarea{-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;}input[type=submit], input[type=button], a.button, .button, .woocommerce .page_slider a.button, a.button.fullwidth, .woocommerce-page div.product form.cart .button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"] .form-wrapper input[type="submit"], body .ui-dialog[aria-describedby="ajax-login-register-dialog"] .form-wrapper input[type="submit"], .select2-container--default .select2-selection--single{font-family:Roboto;font-size:16px;font-weight:400;line-height:1.7;text-transform:none;}input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=date], textarea, .widget_search form{background-color:#ffffff;}input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=date], textarea.widget_search input.search-field{color:#181B31;}input[type=text], input[type=password], input[type=email], input[type=url], input[type=tel], input[type=date], textarea, .select2-container--default .select2-selection--single, .select2-dropdown, .widget_search form{border-color:#d8d8d8;}input[type=text]:focus, input[type=password]:focus, input[type=email]:focus, input[type=url]:focus, input[type=date]:focus, textarea:focus, .widget_search form.focus{border-color:#181B31;}.input-effect ~ .focus-border{background-color:#181B31;}input[type=submit], input[type=button], a.button, .button, .woocommerce .page_slider a.button, a.button.fullwidth, .woocommerce-page div.product form.cart .button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"] .form-wrapper input[type="submit"], body .ui-dialog[aria-describedby="ajax-login-register-dialog"] .form-wrapper input[type="submit"], body.learnpress-page #page-content-wrapper .order-recover .lp-button, .learnpress-page #learn-press-profile-basic-information button, body #page-content-wrapper p#lp-avatar-actions button, .learnpress-page #profile-content-settings form button[type=submit], button, .woocommerce #respond input#submit{font-family:Cabin;font-size:14px;font-weight:700;letter-spacing:0px;line-height:1.8;text-transform:none;}input[type=submit], input[type=button], a.button, .button, .woocommerce .page_slider a.button, a.button.fullwidth, .woocommerce-page div.product form.cart .button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"] .form-wrapper input[type="submit"], body .ui-dialog[aria-describedby="ajax-login-register-dialog"] .form-wrapper input[type="submit"], a#go-to-top, .pagination span, .widget_tag_cloud div a, .pagination a, .pagination span, body.learnpress-page #page-content-wrapper .order-recover .lp-button, .learnpress-page #learn-press-profile-basic-information button, body #page-content-wrapper p#lp-avatar-actions button, .learnpress-page #profile-content-settings form button[type=submit], .learnpress-page #page-content-wrapper .lp-button, button, .woocommerce #respond input#submit{-webkit-border-radius:5px;-moz-border-radius:5px;border-radius:5px;}input[type=submit], input[type=button], a.button, .button, .pagination span, .pagination a:hover, .woocommerce .footer-main-container .button, .woocommerce .footer-main-container .button:hover, .woocommerce-page div.product form.cart .button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .post-type-icon, .filter li a:hover, .filter li a.active, #portfolio_wall_filters li a.active, #portfolio_wall_filters li a:hover, .comment_box, .one-half.gallery2 .portfolio_type_wrapper, .one-third.gallery3 .portfolio_type_wrapper, .one_fourth.gallery4 .portfolio_type_wrapper, .one_fifth.gallery5 .portfolio_type_wrapper, .portfolio_type_wrapper, .widget_tag_cloud div a:hover, .ui-accordion .ui-accordion-header .ui-icon, .mobile-menu-wrapper #mobile-menu-close.button, .mobile-menu-wrapper #btn-close-mobile-menu, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"] .form-wrapper input[type="submit"], body .ui-dialog[aria-describedby="ajax-login-register-dialog"] .form-wrapper input[type="submit"], .learnpress-page #page-content-wrapper .lp-button, .learnpress-page #learn-press-profile-basic-information button, .learnpress-page #profile-content-settings form button[type=submit], button, .widget_search input#searchsubmit:hover, #wp-calendar caption, #wp-calendar thead th, #page-content-wrapper .sidebar .content .sidebar-widget li.widget_categories .cat-count, .widget_categories .cat-count, #page-content-wrapper .sidebar .content .sidebar-widget li.widget_archive .archive-count, .widget_archive .archive-count, .woocommerce #respond input#submit{background-color:#fbb315;}.pagination span, .pagination a:hover, .button.ghost, .button.ghost:hover, .button.ghost:active, blockquote:after, .woocommerce-MyAccount-navigation ul li.is-active, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"] .form-wrapper input[type="submit"], body .ui-dialog[aria-describedby="ajax-login-register-dialog"] .form-wrapper input[type="submit"], .learnpress-page #page-content-wrapper .lp-button, .learnpress-page #learn-press-profile-basic-information button, .learnpress-page #profile-content-settings form button[type=submit], .widget_search input#searchsubmit:hover{border-color:#fbb315;}.comment_box:before, .comment_box:after{border-top-color:#fbb315;}.button.ghost, .button.ghost:hover, .button.ghost:active, .infinite_load_more, blockquote:before, .woocommerce-MyAccount-navigation ul li.is-active a, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"] .form-wrapper input[type="submit"], body .ui-dialog[aria-describedby="ajax-login-register-dialog"] .form-wrapper input[type="submit"], #page-content-wrapper .inner .sidebar-wrapper .sidebar-widget li.widget_recent_comments ul li.recentcomments a:not(.url){color:#fbb315;}input[type=submit], input[type=button], a.button, .button, .pagination a:hover, .woocommerce .footer-main-container .button , .woocommerce .footer-main-container .button:hover, .woocommerce-page div.product form.cart .button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .post-type-icon, .filter li a:hover, .filter li a.active, #portfolio_wall_filters li a.active, #portfolio_wall_filters li a:hover, .comment_box, .one-half.gallery2 .portfolio_type_wrapper, .one-third.gallery3 .portfolio_type_wrapper, .one_fourth.gallery4 .portfolio_type_wrapper, .one_fifth.gallery5 .portfolio_type_wrapper, .portfolio_type_wrapper, .widget_tag_cloud div a:hover, .ui-accordion .ui-accordion-header .ui-icon, .mobile-menu-wrapper #mobile-menu-close.button, #go-to-top, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"] .form-wrapper input[type="submit"], body .ui-dialog[aria-describedby="ajax-login-register-dialog"] .form-wrapper input[type="submit"],.pagination span.current, .mobile-menu-wrapper #btn-close-mobile-menu, body.learnpress-page #page-content-wrapper .lp-button, .learnpress-page #learn-press-profile-basic-information button, .learnpress-page #profile-content-settings form button[type=submit], button, .widget_search input#searchsubmit:hover, #wp-calendar caption, #wp-calendar thead th, #page-content-wrapper .sidebar .content .sidebar-widget li.widget_categories .cat-count, .widget_categories .cat-count, #page-content-wrapper .sidebar .content .sidebar-widget li.widget_archive .archive-count, .widget_archive .archive-count, .woocommerce #respond input#submit{color:#ffffff;}input[type=submit], input[type=button], a.button, .button, .pagination a:hover, .woocommerce .footer-main-container .button , .woocommerce .footer-main-container .button:hover, .woocommerce-page div.product form.cart .button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .infinite_load_more, .widget_tag_cloud div a:hover, .mobile-menu-wrapper #btn-close-mobile-menu, .mobile-menu-wrapper #mobile-menu-close.button, body .ui-dialog[aria-describedby="ajax-login-register-login-dialog"] .form-wrapper input[type="submit"], body .ui-dialog[aria-describedby="ajax-login-register-dialog"] .form-wrapper input[type="submit"], .learnpress-page #learn-press-profile-basic-information button, .learnpress-page #profile-content-settings form button[type=submit], button, .woocommerce #respond input#submit{border-color:#fbb315;}#wp-calendar tbody td#today{border-bottom-color:#fbb315;}input[type=button]:hover, input[type=submit]:hover, a.button:hover, .button:hover, .button.submit, a.button.white:hover, .button.white:hover, a.button.white:active, .button.white:active, .black_bg input[type=submit], .learnpress-page #page-content-wrapper .lp-button:hover, .learnpress-page #learn-press-profile-basic-information button:hover, .learnpress-page #profile-content-settings form button[type=submit]:hover, .woocommerce #respond input#submit:hover{background-color:#ffffff;}input[type=button]:hover, input[type=submit]:hover, a.button:hover, .button:hover, .button.submit, a.button.white:hover, .button.white:hover, a.button.white:active, .button.white:active, .black_bg input[type=submit], body.learnpress-page #page-content-wrapper .lp-button:hover, .learnpress-page #learn-press-profile-basic-information button:hover, .learnpress-page #profile-content-settings form button[type=submit]:hover, button:hover, .woocommerce #respond input#submit:hover{color:#fbb315;}input[type=button]:hover, input[type=submit]:hover, a.button:hover, .button:hover, .button.submit, a.button.white:hover, .button.white:hover, a.button.white:active, .button.white:active, .black_bg input[type=submit], .learnpress-page #learn-press-profile-basic-information button:hover, .learnpress-page #profile-content-settings form button[type=submit]:hover, button:hover, .woocommerce #respond input#submit:hover{border-color:#fbb315;}.frame_top, .frame_bottom, .frame_left, .frame_right{background:#000000;}#menu-wrapper .nav ul li a, #menu-wrapper div .nav li > a, .menu-client-wrapper{font-family:Barlow;font-size:16px;font-weight:500;letter-spacing:0px;line-height:1.7;text-transform:none;}#menu-wrapper .nav ul li, #menu-wrapper div .nav li, html[data-menu=center-menu-logo] #logo-right-wrapper{padding-top:28px;padding-bottom:28px;}.top-menu-bar, html{background-color:#011826;}#menu-wrapper .nav ul li a, #menu-wrapper div .nav li > a, #mobile-nav-icon, #logo-wrapper .social-profile-wrapper ul li a, .menu-cart-wrapper a{color:#ffffff;}#mobile-nav-icon{border-color:#ffffff;}#menu-wrapper .nav ul li a.hover, #menu-wrapper .nav ul li a:hover, #menu-wrapper div .nav li a.hover, #menu-wrapper div .nav li a:hover, .menu-cart-wrapper a:hover, #page_share:hover, #logo-wrapper .social-profile-wrapper ul li a:hover{color:#fbb315;}#menu-wrapper .nav ul li a:before, #menu-wrapper div .nav li > a:before{background-color:#fbb315;}#menu-wrapper div .nav > li.current-menu-item > a, #menu-wrapper div .nav > li.current-menu-parent > a, #menu-wrapper div .nav > li.current-menu-ancestor > a, #menu-wrapper div .nav li ul:not(.sub-menu) li.current-menu-item a, #menu-wrapper div .nav li.current-menu-parent ul li.current-menu-item a, #logo-wrapper .social-profile-wrapper ul li a:active{color:#fbb315;}.top-menu-bar, #nav-wrapper{border-color:#fbb315;}.menu-cart-wrapper .cart-counter{background-color:#fbb315;color:#ffffff;}#menu-wrapper .nav ul li ul li a, #menu-wrapper div .nav li ul li a, #menu-wrapper div .nav li.current-menu-parent ul li a{font-family:Cabin;font-size:15px;font-weight:700;text-transform:none;}#menu-wrapper .nav ul li ul li a, #menu-wrapper div .nav li ul li a, #menu-wrapper div .nav li.current-menu-parent ul li a, #menu-wrapper div .nav li.current-menu-parent ul li.current-menu-item a, #menu-wrapper .nav ul li.megamenu ul li ul li a, #menu-wrapper div .nav li.megamenu ul li ul li a{color:#181B31;}#menu-wrapper .nav ul li ul li a:hover, #menu-wrapper div .nav li ul li a:hover, #menu-wrapper div .nav li.current-menu-parent ul li a:hover, #menu-wrapper .nav ul li.megamenu ul li ul li a:hover, #menu-wrapper div .nav li.megamenu ul li ul li a:hover, #menu-wrapper .nav ul li.megamenu ul li ul li a:active, #menu-wrapper div .nav li.megamenu ul li ul li a:active, #menu-wrapper div .nav li.current-menu-parent ul li.current-menu-item a:hover{color:#fbb315;}#menu-wrapper .nav ul li ul li a:before, #menu-wrapper div .nav li ul li > a:before, #wrapper.transparent .top-menu-bar:not(.scroll) #menu-wrapper div .nav ul li ul li a:before{background-color:#fbb315;}#menu-wrapper .nav ul li ul, #menu-wrapper div .nav li ul{background:#ffffff;border-color:#ffffff;}#menu-wrapper div .nav li.megamenu ul li > a, #menu-wrapper div .nav li.megamenu ul li > a:hover, #menu-wrapper div .nav li.megamenu ul li > a:active, #menu-wrapper div .nav li.megamenu ul li.current-menu-item > a{color:#181B31;}#menu-wrapper div .nav li.megamenu ul li{border-color:#D8D8D8;}.above-top-menu-bar{background:#ffffff;}#top-menu li a, .top-contact-info, .top-contact-info i, .top-contact-info a, .top-contact-info a:hover, .top-contact-info a:active{color:#181B31;}.mobile-main-nav li a, #side-sub-menu li a{font-family:Cabin;font-size:18px;font-weight:700;line-height:2;text-transform:none;}#side-sub-menu li a{font-family:Cabin;font-size:18px;font-weight:700;line-height:2;text-transform:none;}.mobile-menu-wrapper{background-color:#ffffff;}.mobile-main-nav li a, #side-sub-menu li a, .mobile-menu-wrapper .sidebar-wrapper a, .mobile-menu-wrapper .sidebar-wrapper, #btn-close-mobile-menu i, .mobile-menu-wrapper .social-profile-wrapper ul li a, .fullmenu_content #copyright, .mobile-menu-wrapper .sidebar-wrapper h2.widgettitle{color:#181B31;}.mobile-main-nav li a:hover, .mobile-main-nav li a:active, #side-sub-menu li a:hover, #side-sub-menu li a:active, .mobile-menu-wrapper .social-profile-wrapper ul li a:hover{color:#fbb315;}#page-header.hasbg{height:600px;}#page-header{background-color:#011826;padding-top:60px;padding-bottom:60px;margin-bottom:45px;}#page-header .page-title-wrapper .page-title-inner{text-align:center;}#page-header h1{font-family:Cabin;font-size:45px;font-weight:700;line-height:1.2;text-transform:none;color:#181b31;}.page-tagline, .post-detail.single-post{font-family:Roboto;font-size:14px;font-weight:500;text-transform:none;color:#7e8090;}#page-content-wrapper .sidebar .content .sidebar-widget li h2.widgettitle, h2.widgettitle, h5.widgettitle{font-family:Cabin;font-size:13px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#181B31;border-color:#181B31;}#page-content-wrapper .inner .sidebar-wrapper .sidebar .content, .page-content-wrapper .inner .sidebar-wrapper .sidebar .content{color:#7E8090;}#page-content-wrapper .inner .sidebar-wrapper a:not(.button), .page-content-wrapper .inner .sidebar-wrapper a:not(.button){color:#181B31;}.widget_nav_menu ul > li.menu-item-has-children > a:after{border-color:#181B31;}#page-content-wrapper .inner .sidebar-wrapper a:hover:not(.button), #page-content-wrapper .inner .sidebar-wrapper a:active:not(.button), .page-content-wrapper .inner .sidebar-wrapper a:hover:not(.button), .page-content-wrapper .inner .sidebar-wrapper a:active:not(.button){color:#fbb315;}#footer{font-size:15px;}.footer-main-container-wrapper{font-size:13px;}.footer-main-container, #footer{background-color:#ffffff;}#footer, #copyright, #footer-menu li a, #footer-menu li a:hover, #footer-menu li a:active, #footer input[type=text], #footer input[type=password], #footer input[type=email], #footer input[type=url], #footer input[type=tel], #footer input[type=date], #footer textarea, #footer blockquote{color:#7E8090;}#copyright a, #copyright a:active, #footer a, #footer a:active#footer_photostream a{color:#ffffff;}#footer .sidebar-widget li h2.widgettitle{border-color:#ffffff;color:#181B31;}#copyright a:hover, #footer a:hover, .social-profile-wrapper ul li a:hover, #footer a:hover, #footer_photostream a:hover{color:#ffffff;}#footer table tr td, #footer .widget_tag_cloud div a{border-color:#D8D8D8;}#footer table tbody tr:nth-child(even){background:#D8D8D8;}.footer-main-container{background-color:#011826;}.footer-main-container, #copyright{color:#ffffff;}.footer-main-container a, #copyright a, #footer-menu li a{color:#ffffff;}.footer-main-container a:hover, #copyright a:hover, #footer-menu li a:hover{color:#ffffff;}.footer-main-container-wrapper, .footer-main-container{border-color:#D8D8D8;}.footer-main-container-wrapper .social-profile-wrapper ul li a{color:#181B31;}a#go-to-top{background:rgba(0,0,0,0.1);color:#ffffff;}#page-content-wrapper.blog-wrapper, .post-excerpt.post-tag a:after, .post-excerpt.post-tag a:before, .post-navigation .navigation-post-content{background-color:#ffffff;}.post-info-cat, .post-info-cat a{color:#57B957;border-color:#57B957;}.post-featured-image-hover .post-type-icon{background:#181B31;}.blog_post-content-wrapper.layout_grid .post-content-wrapper, .blog_post-content-wrapper.layout_masonry .post-content-wrapper, .blog_post-content-wrapper.layout_metro .post-content-wrapper, .blog_post-content-wrapper.layout_classic .post-content-wrapper{background:#ffffff;}.post-header h5, h6.subtitle, .post-caption h1, #page-content-wrapper .posts.blog li a, .page-content-wrapper .posts.blog li a, #post_featured_slider li .slider_image .slide_post h2, .post-header.grid h6, .sidebar-widget li.widget_recent_comments ul li.recentcomments a:not(.url), #page-content-wrapper .sidebar .content .sidebar-widget li.widget_rss ul li a.rsswidget, #footer-wrapper ul.sidebar-widget li.widget_rss ul li a.rsswidget{font-family:Cabin;font-weight:700;letter-spacing:0px;text-transform:none;}body.single-post #page-header h1{font-family:Cabin;font-size:40px;font-weight:700;line-height:1.3;text-transform:none;}body.single-post #page-content-wrapper.blog-wrapper, .post-related .post-header-wrapper{background:#ffffff;}.post-excerpt.post-tag a{background:#f0f0f0;color:#444;}.post-excerpt.post-tag a:after{border-left-color:#f0f0f0;}.woocommerce ul.products li.product .price ins, .woocommerce-page ul.products li.product .price ins, .woocommerce ul.products li.product .price, .woocommerce-page ul.products li.product .price, p.price ins span.amount, .woocommerce #content div.product p.price, .woocommerce #content div.product span.price, .woocommerce div.product p.price, .woocommerce div.product span.price, .woocommerce-page #content div.product p.price, .woocommerce-page #content div.product span.price, .woocommerce-page div.product p.price, .woocommerce-page div.product span.price{color:#181B31;}.woocommerce .products .onsale, .woocommerce ul.products li.product .onsale, .woocommerce span.onsale{background-color:#57B957;}.woocommerce div.product .woocommerce-tabs ul.tabs li.active a, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active a{color:#ffffff;}.woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active{background:#181B31;}body.single-product div.product.type-product{background:#ffffff;}
</style>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.2.18' id='tp-tools-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.2.18' id='revmin-js'></script>

<!-- Google Analytics snippet added by Site Kit -->
<script type='text/javascript' src='https://www.googletagmanager.com/gtag/js?id=UA-191869215-1' id='google_gtagjs-js' async></script>
<script type='text/javascript' id='google_gtagjs-js-after'>
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag('set', 'linker', {"domains":["vitaprojects.co.za"]} );
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "UA-191869215-1", {"anonymize_ip":true});
</script>

<!-- End Google Analytics snippet added by Site Kit -->
<link rel="https://api.w.org/" href="https://vitaprojects.co.za/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://vitaprojects.co.za/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://vitaprojects.co.za/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.3" />
<meta name="generator" content="WooCommerce 6.0.0" />
<meta name="generator" content="Site Kit by Google 1.48.1" />	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by Slider Revolution 6.2.18 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://vitaprojects.co.za/wp-content/uploads/2021/02/cropped-VITA_CI_MANUAL-32x32.png" sizes="32x32" />
<link rel="icon" href="https://vitaprojects.co.za/wp-content/uploads/2021/02/cropped-VITA_CI_MANUAL-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://vitaprojects.co.za/wp-content/uploads/2021/02/cropped-VITA_CI_MANUAL-180x180.png" />
<meta name="msapplication-TileImage" content="https://vitaprojects.co.za/wp-content/uploads/2021/02/cropped-VITA_CI_MANUAL-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}				
					if(window.rs_init_css===undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));					
					document.getElementById(e.c).height = newh+"px";
					window.rs_init_css.innerHTML += "#"+e.c+"_wrapper { height: "+newh+"px }";				
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
<style id="loftloader-lite-custom-bg-color">#loftloader-wrapper .loader-section {
	background: #011826;
}
</style><style id="loftloader-lite-custom-bg-opacity">#loftloader-wrapper .loader-section {
	opacity: 0.95;
}
</style><style id="loftloader-lite-custom-loader">#loftloader-wrapper.pl-imgloading #loader {
	width: 300px;
}
#loftloader-wrapper.pl-imgloading #loader span {
	background-size: cover;
	background-image: url(http://vitaprojects.co.za/wp-content/uploads/2021/02/Asset-1.png);
}
</style></head>

<body class="error404 theme-avante woocommerce-no-js lightbox-black leftalign loftloader-lite-enabled elementor-default elementor-kit-12"><div id="loftloader-wrapper" class="pl-imgloading" data-show-close-time="15000" data-max-load-time="0"><div class="loader-inner"><div id="loader"><div class="imgloading-container"><span style="background-image: url(http://vitaprojects.co.za/wp-content/uploads/2021/02/Asset-1.png);"></span></div><img width="300" height="93" data-no-lazy="1" class="skip-lazy" alt="loader image" src="http://vitaprojects.co.za/wp-content/uploads/2021/02/Asset-1.png"></div></div><div class="loader-section section-fade"></div><div class="loader-close-button" style="display: none;"><span class="screen-reader-text">Close</span></div></div>
		<div id="perspective" style="">
	
	<!-- Begin mobile menu -->
<a id="btn-close-mobile-menu" href="javascript:;"></a>

<div class="mobile-menu-wrapper">
	
	<div class="mobile-menu-content">
    	
		
    <div class="menu-main-menu-container"><ul id="mobile_main_menu" class="mobile-main-nav"><li id="menu-item-109" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-109"><a href="https://vitaprojects.co.za/">Home</a></li>
<li id="menu-item-110" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-110"><a href="https://vitaprojects.co.za/why-us/">Why Us?</a></li>
<li id="menu-item-269" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-269"><a href="#">Showcase</a>
<ul class="sub-menu">
	<li id="menu-item-271" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-271"><a href="https://vitaprojects.co.za/st-james/">28 on St. James</a></li>
	<li id="menu-item-270" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-270"><a href="https://vitaprojects.co.za/bishops-court/">Bishops Court</a></li>
	<li id="menu-item-448" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-448"><a href="https://vitaprojects.co.za/fairhaven/">Fairhaven</a></li>
	<li id="menu-item-435" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-435"><a href="https://vitaprojects.co.za/gallery/">Gallery</a></li>
</ul>
</li>
<li id="menu-item-166" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-166"><a href="https://vitaprojects.co.za/contact/">Contact</a></li>
<li id="menu-item-556" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-556"><a href="https://www.facebook.com/vitaprojectsza/"><img src="http://vitaprojects.co.za/wp-content/uploads/2021/04/facebook-1.png;"></a></li>
<li id="menu-item-558" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-558"><a href="https://www.youtube.com/channel/UCjXvmlIPHZ-1eUPOHwMkItg"><img src="http://vitaprojects.co.za/wp-content/uploads/2021/04/youtube.png;"></a></li>
</ul></div>    
        </div>
</div>
<!-- End mobile menu -->
	<!-- Begin template wrapper -->
		<div id="wrapper" class=" ">
	
	
<div class="main-menu-wrapper">
<!-- End top bar -->

<div class="top-menu-bar ">
    <div class="standard-wrapper">
    	<!-- Begin logo -->
    	<div id="logo-wrapper">
    	
    	    	<div id="logo_normal" class="logo-container">
    		<div class="logo-alignment">
	    	    <a id="custom_logo" class="logo-wrapper default" href="https://vitaprojects.co.za/">
	    	    						<img src="http://vitaprojects.co.za/wp-content/uploads/2021/02/Asset-1.png" alt="" width="160" height="50"/>
						    	    </a>
    		</div>
    	</div>
    	    	
    	    	<div id="logo_transparent" class="logo-container">
    		<div class="logo-alignment">
	    	    <a id="custom_logo_transparent" class="logo-wrapper hidden" href="https://vitaprojects.co.za/">
	    	    		    	    	<img src="https://vitaprojects.co.za/wp-content/themes/avante/images/logo@2x_white.png" alt="" style="width:50%;height:auto;"/>
	    	    		    	    </a>
    		</div>
    	</div>
    	    	<!-- End logo -->
    	
        <div id="menu-wrapper">
	        <div id="nav-wrapper">
	        	<div class="nav-wrapper-inner">
	        		<div id="menu-border-wrapper">
	        			<div class="menu-main-menu-container"><ul id="main_menu" class="nav"><li class=' menu-item menu-item-type-post_type menu-item-object-page menu-item-home'><a href="https://vitaprojects.co.za/">Home</a></li>
<li class=' menu-item menu-item-type-post_type menu-item-object-page'><a href="https://vitaprojects.co.za/why-us/">Why Us?</a></li>
<li class=' menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children arrow'><a href="#">Showcase</a>
<ul class="sub-menu">
<li class=' menu-item menu-item-type-post_type menu-item-object-page'><a href="https://vitaprojects.co.za/st-james/">28 on St. James</a></li>
<li class=' menu-item menu-item-type-post_type menu-item-object-page'><a href="https://vitaprojects.co.za/bishops-court/">Bishops Court</a></li>
<li class=' menu-item menu-item-type-post_type menu-item-object-page'><a href="https://vitaprojects.co.za/fairhaven/">Fairhaven</a></li>
<li class=' menu-item menu-item-type-post_type menu-item-object-page'><a href="https://vitaprojects.co.za/gallery/">Gallery</a></li>
</ul>
</li>
<li class=' menu-item menu-item-type-post_type menu-item-object-page'><a href="https://vitaprojects.co.za/contact/">Contact</a></li>
<li class=' menu-item menu-item-type-custom menu-item-object-custom'><a href="https://www.facebook.com/vitaprojectsza/"><img src="http://vitaprojects.co.za/wp-content/uploads/2021/04/facebook-1.png;"></a></li>
<li class=' menu-item menu-item-type-custom menu-item-object-custom'><a href="https://www.youtube.com/channel/UCjXvmlIPHZ-1eUPOHwMkItg"><img src="http://vitaprojects.co.za/wp-content/uploads/2021/04/youtube.png;"></a></li>
</ul></div>	        		</div>
	        	</div>
	        </div>
	        <!-- End main nav -->
        </div>
        
        <!-- Begin right corner buttons -->
        <div id="logo_right_wrapper">
			<div id="logo-right-wrapper">
			
						
						 
			 <!-- Begin side menu -->
			 		     	<a href="javascript:;" id="mobile-nav-icon"><span class="ti-menu"></span></a>
		     			 <!-- End side menu -->
			</div>
		</div>
		<!-- End right corner buttons -->
        
    	</div>
		</div>
    </div>
</div>

<!-- Begin content -->

<div id="page-content-wrapper">

    <div class="inner">
    
    	<!-- Begin main content -->
    	<div class="inner-wrapper">
	    	
	    	<h1>Oops! This page can’t befound anywhere.</h1>
    	
	    	<div class="search-form-wrapper">
		    	We&#039;re sorry, the page you have looked for does not exist in our content! Perhaps you would like to go to our homepage or try searching below.		    	<br/><br/>
		    	
	    		<form class="searchform" method="get" action="https://vitaprojects.co.za/">
		    		<p class="input-wrapper">
			    		<input type="text" class="input-effect field searchform-s" name="s" value="" placeholder="Type to search...">
						<input type="submit" value="Search"/>
		    		</p>
			    </form>
    		</div>
	    	
	    	<br/>
	    	
    		</div>
    	</div>
    	
</div>
<br class="clear"/>
</div>
<div id="footer-wrapper">
<div id="footer" class=" ">
</div>
	<div class="footer-main-container   ">
	
		<div class="footer-main-container-wrapper ">
			<div class="menu-main-menu-container"><ul id="footer-menu" class="footer_nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-109"><a href="https://vitaprojects.co.za/">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-110"><a href="https://vitaprojects.co.za/why-us/">Why Us?</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-269"><a href="#">Showcase</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-271"><a href="https://vitaprojects.co.za/st-james/">28 on St. James</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-270"><a href="https://vitaprojects.co.za/bishops-court/">Bishops Court</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-448"><a href="https://vitaprojects.co.za/fairhaven/">Fairhaven</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-435"><a href="https://vitaprojects.co.za/gallery/">Gallery</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-166"><a href="https://vitaprojects.co.za/contact/">Contact</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-556"><a href="https://www.facebook.com/vitaprojectsza/"><img src="http://vitaprojects.co.za/wp-content/uploads/2021/04/facebook-1.png;"></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-558"><a href="https://www.youtube.com/channel/UCjXvmlIPHZ-1eUPOHwMkItg"><img src="http://vitaprojects.co.za/wp-content/uploads/2021/04/youtube.png;"></a></li>
</ul></div>		    <div id="copyright">© 2021 Vita. All Rights Reserved | Powered by HEADLIGHT Media | <a href="https://vitaprojects.co.za/privacy-policy/">Privacy Policy</a></div><br class="clear"/>		</div>
	</div>
	</div>

 	<a id="go-to-top" href="javascript:;"><span class="ti-arrow-up"></span></a>



</div>
	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<script type='text/javascript' src='https://vitaprojects.co.za/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-includes/js/masonry.min.js?ver=4.2.2' id='masonry-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/avante-elementor/assets/js/jquery.lazy.js?ver=5.8.3' id='lazy-js'></script>
<script type='text/javascript' id='lazy-js-after'>
		jQuery(function( $ ) {
			jQuery("img.lazy").each(function() {
				var currentImg = jQuery(this);
				
				jQuery(this).Lazy({
					onFinishedAll: function() {
						currentImg.parent("div.post-featured-image-hover").removeClass("lazy");
						currentImg.parent(".tg_gallery_lightbox").parent("div.gallery_grid_item").removeClass("lazy");
						currentImg.parent("div.gallery_grid_item").removeClass("lazy");
			        }
				});
			});
		});
		
</script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/avante-elementor/assets/js/modulobox.js?ver=5.8.3' id='modulobox-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/avante-elementor/assets/js/jquery.parallax-scroll.js?ver=5.8.3' id='parallax-scroll-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/avante-elementor/assets/js/jquery.smoove.js?ver=5.8.3' id='smoove-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/avante-elementor/assets/js/parallax.js?ver=5.8.3' id='parallax-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/avante-elementor/assets/js/jquery.sticky-kit.min.js?ver=5.8.3' id='sticky-kit-js'></script>
<script type='text/javascript' id='sticky-kit-js-after'>
		jQuery(function( $ ) {
			jQuery("#page-content-wrapper .sidebar-wrapper").stick_in_parent({ offset_top: 100 });
			
			if(jQuery(window).width() < 768 || is_touch_device())
			{
				jQuery("#page-content-wrapper .sidebar-wrapper").trigger("sticky_kit:detach");
			}
		});
		
</script>
<script type='text/javascript' id='avante-elementor-js-extra'>
/* <![CDATA[ */
var tgAjax = {"ajaxurl":"https:\/\/vitaprojects.co.za\/wp-admin\/admin-ajax.php","ajax_nonce":"73c3e12d9d"};
/* ]]> */
</script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/avante-elementor/assets/js/avante-elementor.js?ver=5.8.3' id='avante-elementor-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.7' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/vitaprojects.co.za\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.5.3' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.6.0.0' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/vitaprojects.co.za\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=6.0.0' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.6.0.0' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=6.0.0' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_78d075385e0a89953226cdc68b939cf5","fragment_name":"wc_fragments_78d075385e0a89953226cdc68b939cf5","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=6.0.0' id='wc-cart-fragments-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-includes/js/jquery/ui/core.min.js?ver=1.12.1' id='jquery-ui-core-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-includes/js/jquery/ui/effect.min.js?ver=1.12.1' id='jquery-effects-core-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/avante-elementor/assets/js/tweenmax.min.js?ver=5.8.3' id='tweenmax-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/themes/avante/js/waypoints.min.js?ver=5.8.3' id='waypoints-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/themes/avante/js/jquery.stellar.min.js?ver=5.8.3' id='stellar-js'></script>
<script type='text/javascript' id='avante-custom-plugins-js-extra'>
/* <![CDATA[ */
var avantePluginParams = {"backTitle":"Back"};
/* ]]> */
</script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/themes/avante/js/core/custom_plugins.js?ver=5.8.3' id='avante-custom-plugins-js'></script>
<script type='text/javascript' id='avante-custom-script-js-extra'>
/* <![CDATA[ */
var avanteParams = {"menulayout":"leftalign","fixedmenu":"1","footerreveal":"","headercontent":"menu","lightboxthumbnails":"thumbnail","lightboxtimer":"7000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/themes/avante/js/core/custom.js?ver=5.8.3' id='avante-custom-script-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/themes/avante/js/jquery.tooltipster.min.js?ver=5.8.3' id='tooltipster-js'></script>
<script type='text/javascript' id='tooltipster-js-after'>
	jQuery(function( $ ) {
		jQuery(".demotip").tooltipster({
			position: "left",
			multiple: true,
			theme: "tooltipster-shadow",
			delay: 0
		});
	});
	
</script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/plugins/loftloader/assets/js/loftloader.min.js?ver=2021102001' id='loftloader-lite-front-main-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<script type='text/javascript' src='https://vitaprojects.co.za/wp-content/themes/avante/modules/kirki/assets/webfont.js?ver=3.0.21' id='webfont-loader-js'></script>
<script type='text/javascript' id='webfont-loader-js-after'>
WebFont.load({google:{families:['Roboto:500', 'Cabin:700', 'Barlow:500']}});
</script>
</body>
</html>
